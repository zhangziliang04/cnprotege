#protege汉化版
配置环境：需要使用jdk1.8
